import logo from './logo.svg';
import './App.css';
import ImageUploadForm from './ImageUploadForm';
function App() {
  return (
    <div className="App">
    <ImageUploadForm />
    </div>
  );
}

export default App;
