const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const { v2: cloudinary } = require('cloudinary');
const app = express();
require('dotenv').config();
const PORT = process.env.PORT || 5000;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Cloudinary Configuration
cloudinary.config({
    cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
    api_key: process.env.CLOUDINARY_API_KEY,
    api_secret: process.env.CLOUDINARY_API_SECRET,
  });

  const UserRoutes = require('./routes/UserRoutes');
  app.use('/api', UserRoutes); 

  // MongoDB Configuration
mongoose.connect(process.env.MONGODB_URI, { useNewUrlParser: true, useUnifiedTopology: true });

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
  